import React, { useState } from 'react';
import { Incident } from '../types/Incident';


interface Props {
  incident: Incident;
}

const IncidentCard: React.FC<Props> = ({ incident }) => {
  const [showDescription, setShowDescription] = useState(false);

  return (
    <div className="incident-card">
      <h3>{incident.title}</h3>
      <p>Severity: {incident.severity}</p>
      <p>Reported on: {new Date(incident.reported_at).toLocaleDateString()}</p>
      <button onClick={() => setShowDescription(!showDescription)}>
        {showDescription ? 'Hide Details' : 'View Details'}
      </button>
      {showDescription && <p className="description">{incident.description}</p>}
    </div>
  );
};

export default IncidentCard;

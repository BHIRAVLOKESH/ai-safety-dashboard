import React, { useState } from 'react';
import { Incident } from '../types/Incident';
import { mockData } from '../data/mockData';
import IncidentCard from './IncidentCard';
import NewIncidentForm from './NewIncidentForm';


const IncidentDashboard: React.FC = () => {
  const [incidents, setIncidents] = useState<Incident[]>(mockData);
  const [filter, setFilter] = useState<string>('All');
  const [sortOrder, setSortOrder] = useState<string>('Newest');

  const handleNewIncident = (newIncident: Incident) => {
    setIncidents([newIncident, ...incidents]);
  };

  const filteredIncidents = incidents.filter(incident =>
    filter === 'All' ? true : incident.severity === filter
  );

  const sortedIncidents = filteredIncidents.sort((a, b) => {
    const dateA = new Date(a.reported_at).getTime();
    const dateB = new Date(b.reported_at).getTime();
    return sortOrder === 'Newest' ? dateB - dateA : dateA - dateB;
  });

  return (
    <div>
      <div className="controls">
        <select onChange={(e) => setFilter(e.target.value)}>
          <option value="All">All Severities</option>
          <option value="Low">Low</option>
          <option value="Medium">Medium</option>
          <option value="High">High</option>
        </select>

        <select onChange={(e) => setSortOrder(e.target.value)}>
          <option value="Newest">Newest First</option>
          <option value="Oldest">Oldest First</option>
        </select>
      </div>

      {sortedIncidents.map(incident => (
        <IncidentCard key={incident.id} incident={incident} />
      ))}

      <NewIncidentForm onAddIncident={handleNewIncident} />
    </div>
  );
};

export default IncidentDashboard;

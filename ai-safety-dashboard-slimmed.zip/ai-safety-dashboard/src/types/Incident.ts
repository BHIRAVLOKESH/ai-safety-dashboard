export interface Incident {
    id: number;
    title: string;
    description: string;
    severity: 'Low' | 'Medium' | 'High';
    reported_at: string; // ISO date string like "2025-03-15T10:00:00Z"
  }
  
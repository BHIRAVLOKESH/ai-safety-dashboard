import React from 'react';
import IncidentDashboard from './components/IncidentDashboard';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>AI Safety Incident Dashboard</h1>
      <IncidentDashboard />
    </div>
  );
}

export default App;
